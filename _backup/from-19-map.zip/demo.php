<?php
$province = $_POST['province'];
$city     = $_POST['city'];
echo json_encode(array(
    'text' => '你好这里是：' . $province . '--' .$city
));